/**
 * Pulse Social - API Client Service
 */

const API_BASE = '/api';

const API = {
  getToken() {
    return localStorage.getItem('pulse_token');
  },

  setToken(token) {
    if (token) {
      localStorage.setItem('pulse_token', token);
    } else {
      localStorage.removeItem('pulse_token');
    }
  },

  clearToken() {
    localStorage.removeItem('pulse_token');
    localStorage.removeItem('pulse_user');
  },

  getCurrentUser() {
    try {
      const data = localStorage.getItem('pulse_user');
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  },

  setCurrentUser(user) {
    if (user) {
      localStorage.setItem('pulse_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('pulse_user');
    }
  },

  async request(endpoint, options = {}) {
    const headers = options.headers || {};
    const token = this.getToken();

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    // Don't set Content-Type if body is FormData (let browser set multipart boundary)
    if (!(options.body instanceof FormData) && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    const config = {
      ...options,
      headers
    };

    try {
      const res = await fetch(`${API_BASE}${endpoint}`, config);
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(data.error || `Request failed with status ${res.status}`);
      }

      return data;
    } catch (err) {
      console.error(`API Error on [${options.method || 'GET'} ${endpoint}]:`, err.message);
      throw err;
    }
  },

  // Auth Endpoints
  async getDemoUsers() {
    return this.request('/auth/demo-users');
  },

  async demoLogin(username) {
    const res = await this.request('/auth/demo-login', {
      method: 'POST',
      body: JSON.stringify({ username })
    });
    this.setToken(res.token);
    this.setCurrentUser(res.user);
    return res;
  },

  async login(loginId, password) {
    const res = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ loginId, password })
    });
    this.setToken(res.token);
    this.setCurrentUser(res.user);
    return res;
  },

  async register(userData) {
    const res = await this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
    this.setToken(res.token);
    this.setCurrentUser(res.user);
    return res;
  },

  async getMe() {
    return this.request('/auth/me');
  },

  async logout() {
    try {
      await this.request('/auth/logout', { method: 'POST' });
    } catch (e) {
      // ignore
    }
    this.clearToken();
  },

  // Post Endpoints
  async getPosts(params = {}) {
    const query = new URLSearchParams();
    if (params.search) query.set('search', params.search);
    if (params.userId) query.set('userId', params.userId);
    const queryString = query.toString() ? `?${query.toString()}` : '';
    return this.request(`/posts${queryString}`);
  },

  async getPost(id) {
    return this.request(`/posts/${id}`);
  },

  async createPost(formDataOrJson) {
    const isFormData = formDataOrJson instanceof FormData;
    return this.request('/posts', {
      method: 'POST',
      body: isFormData ? formDataOrJson : JSON.stringify(formDataOrJson)
    });
  },

  async deletePost(id) {
    return this.request(`/posts/${id}`, {
      method: 'DELETE'
    });
  },

  async toggleLike(postId) {
    return this.request(`/posts/${postId}/like`, {
      method: 'POST'
    });
  },

  // Comment Endpoints
  async getComments(postId) {
    return this.request(`/posts/${postId}/comments`);
  },

  async addComment(postId, text) {
    return this.request(`/posts/${postId}/comments`, {
      method: 'POST',
      body: JSON.stringify({ text })
    });
  },

  async deleteComment(postId, commentId) {
    return this.request(`/posts/${postId}/comments/${commentId}`, {
      method: 'DELETE'
    });
  },

  // User Endpoints
  async getProfile(username) {
    return this.request(`/users/${username}`);
  },

  async getSuggestions() {
    return this.request('/users');
  }
};

window.API = API;
