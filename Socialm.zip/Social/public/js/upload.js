/**
 * Pulse Social - Photo Upload & Post Creation Controller
 */

const Upload = {
  selectedFile: null,
  activeTab: 'file', // 'file' or 'url'

  init() {
    this.setupDropzone();
    this.setupForm();
  },

  openModal() {
    if (!Auth.currentUser) {
      Auth.showAuthModal('login');
      App.showToast('Please log in to share photos', 'info');
      return;
    }

    const modal = document.getElementById('createPostModal');
    if (modal) {
      this.resetModal();
      modal.showModal();
    }
  },

  closeModal() {
    const modal = document.getElementById('createPostModal');
    if (modal) {
      modal.close();
    }
  },

  resetModal() {
    this.selectedFile = null;
    this.activeTab = 'file';
    this.switchTab('file');

    const form = document.getElementById('createPostForm');
    if (form) form.reset();

    const previewBox = document.getElementById('uploadPreviewBox');
    const previewImg = document.getElementById('uploadPreviewImg');
    const dropzone = document.getElementById('uploadDropzone');

    if (previewBox) previewBox.style.display = 'none';
    if (previewImg) previewImg.src = '';
    if (dropzone) dropzone.style.display = 'flex';
  },

  switchTab(tab) {
    this.activeTab = tab;
    const tabFile = document.getElementById('uploadTabFile');
    const tabUrl = document.getElementById('uploadTabUrl');
    const sectionFile = document.getElementById('uploadSectionFile');
    const sectionUrl = document.getElementById('uploadSectionUrl');

    if (tab === 'file') {
      tabFile.classList.add('active');
      tabUrl.classList.remove('active');
      sectionFile.style.display = 'block';
      sectionUrl.style.display = 'none';
    } else {
      tabFile.classList.remove('active');
      tabUrl.classList.add('active');
      sectionFile.style.display = 'none';
      sectionUrl.style.display = 'block';
    }
  },

  setupDropzone() {
    const dropzone = document.getElementById('uploadDropzone');
    const fileInput = document.getElementById('photoFileInput');

    if (!dropzone || !fileInput) return;

    dropzone.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (e) => {
      if (e.target.files && e.target.files[0]) {
        this.handleFileSelected(e.target.files[0]);
      }
    });

    ['dragenter', 'dragover'].forEach(name => {
      dropzone.addEventListener(name, (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
      });
    });

    ['dragleave', 'drop'].forEach(name => {
      dropzone.addEventListener(name, (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
      });
    });

    dropzone.addEventListener('drop', (e) => {
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        this.handleFileSelected(e.dataTransfer.files[0]);
      }
    });

    // Handle URL preview change
    const urlInput = document.getElementById('photoUrlInput');
    if (urlInput) {
      urlInput.addEventListener('input', () => {
        const val = urlInput.value.trim();
        if (val.startsWith('http://') || val.startsWith('https://')) {
          this.showPreview(val);
        }
      });
    }
  },

  handleFileSelected(file) {
    if (!file.type.startsWith('image/')) {
      App.showToast('Please select a valid image file (JPEG, PNG, WebP)', 'error');
      return;
    }

    if (file.size > 15 * 1024 * 1024) {
      App.showToast('Image size cannot exceed 15MB', 'error');
      return;
    }

    this.selectedFile = file;
    const objectUrl = URL.createObjectURL(file);
    this.showPreview(objectUrl);
  },

  showPreview(src) {
    const previewBox = document.getElementById('uploadPreviewBox');
    const previewImg = document.getElementById('uploadPreviewImg');
    const dropzone = document.getElementById('uploadDropzone');

    if (previewImg && previewBox) {
      previewImg.src = src;
      previewBox.style.display = 'block';
      if (this.activeTab === 'file' && dropzone) {
        dropzone.style.display = 'none';
      }
    }
  },

  removePreview() {
    this.selectedFile = null;
    const previewBox = document.getElementById('uploadPreviewBox');
    const previewImg = document.getElementById('uploadPreviewImg');
    const dropzone = document.getElementById('uploadDropzone');
    const fileInput = document.getElementById('photoFileInput');
    const urlInput = document.getElementById('photoUrlInput');

    if (previewBox) previewBox.style.display = 'none';
    if (previewImg) previewImg.src = '';
    if (dropzone) dropzone.style.display = 'flex';
    if (fileInput) fileInput.value = '';
    if (urlInput) urlInput.value = '';
  },

  setupForm() {
    const form = document.getElementById('createPostForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const caption = document.getElementById('postCaptionInput').value.trim();
      const location = document.getElementById('postLocationInput').value.trim();
      const submitBtn = form.querySelector('button[type="submit"]');

      let payload;
      if (this.activeTab === 'file') {
        if (!this.selectedFile) {
          App.showToast('Please select a photo to share', 'error');
          return;
        }
        const formData = new FormData();
        formData.append('photo', this.selectedFile);
        formData.append('caption', caption);
        formData.append('location', location);
        payload = formData;
      } else {
        const photoUrl = document.getElementById('photoUrlInput').value.trim();
        if (!photoUrl) {
          App.showToast('Please provide an image link', 'error');
          return;
        }
        payload = { photoUrl, caption, location };
      }

      try {
        submitBtn.disabled = true;
        submitBtn.innerHTML = `
          <div style="display: inline-block; width: 18px; height: 18px; border: 2px solid white; border-top-color: transparent; border-radius: 50%; animation: spin 0.8s linear infinite;"></div>
          <span>Sharing photo...</span>
        `;

        const res = await API.createPost(payload);
        this.closeModal();
        App.showToast('Photo published successfully! 📸', 'success');

        // Prepend new post to feed
        Feed.posts.unshift(res.post);
        Feed.renderFeed();

        // Scroll to top of feed
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } catch (err) {
        App.showToast(err.message, 'error');
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = `<span>Share Post</span>`;
      }
    });
  }
};

window.Upload = Upload;
