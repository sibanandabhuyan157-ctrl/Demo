/**
 * Pulse Social - Feed & Interactive Post Cards (Likes, Comments, Media)
 */

const Feed = {
  posts: [],
  expandedComments: new Set(), // tracks which posts have full comment thread shown

  formatTime(isoString) {
    if (!isoString) return 'Just now';
    const now = new Date();
    const past = new Date(isoString);
    const diffSec = Math.floor((now - past) / 1000);

    if (diffSec < 60) return 'Just now';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
    if (diffSec < 604800) return `${Math.floor(diffSec / 86400)}d ago`;
    return past.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  },

  formatCaption(text) {
    if (!text) return '';
    // Escape HTML first
    const div = document.createElement('div');
    div.textContent = text;
    const escaped = div.innerHTML;

    // Highlight hashtags
    return escaped.replace(/#(\w+)/g, '<a href="javascript:void(0)" class="hashtag" onclick="App.searchTag(\'$1\')">#$1</a>');
  },

  async loadFeed(params = {}) {
    const feedContainer = document.getElementById('postsFeed');
    if (!feedContainer) return;

    feedContainer.innerHTML = `
      <div style="text-align: center; padding: 48px; color: var(--text-muted);">
        <div style="display: inline-block; width: 32px; height: 32px; border: 3px solid rgba(99,102,241,0.3); border-top-color: #6366f1; border-radius: 50%; animation: spin 0.8s linear infinite;"></div>
        <p style="margin-top: 12px; font-weight: 500;">Loading feed...</p>
      </div>
    `;

    try {
      const res = await API.getPosts(params);
      this.posts = res.posts || [];
      this.renderFeed();
    } catch (err) {
      feedContainer.innerHTML = `
        <div style="text-align: center; padding: 48px; color: #f43f5e;">
          <p>Failed to load posts. Please try again.</p>
          <button class="btn-primary" style="width: auto; margin: 16px auto; padding: 8px 18px;" onclick="App.refreshFeed()">Retry</button>
        </div>
      `;
    }
  },

  renderFeed() {
    const feedContainer = document.getElementById('postsFeed');
    if (!feedContainer) return;

    if (this.posts.length === 0) {
      feedContainer.innerHTML = `
        <div class="post-card" style="text-align: center; padding: 48px 24px;">
          <div style="font-size: 42px; margin-bottom: 12px;">📷</div>
          <h3 style="font-size: 18px; margin-bottom: 6px;">No posts yet</h3>
          <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 20px;">
            Be the first to share a beautiful photo with the community!
          </p>
          <button class="btn-primary" style="max-width: 200px; margin: 0 auto;" onclick="Upload.openModal()">
            Create First Post
          </button>
        </div>
      `;
      return;
    }

    feedContainer.innerHTML = this.posts.map(post => this.renderPostCard(post)).join('');
  },

  renderPostCard(post) {
    const isLiked = post.isLikedByMe;
    const author = post.author || {};
    const currentUser = Auth.currentUser;
    const isOwner = currentUser && (post.userId === currentUser.id);
    const isExpanded = this.expandedComments.has(post.id);

    return `
      <article class="post-card" id="post-${post.id}">
        <!-- Post Header -->
        <header class="post-header">
          <div class="post-author-info" onclick="App.viewProfile('${author.username}')">
            <img src="${author.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + author.username}" 
                 alt="${author.name}" 
                 class="post-author-avatar" 
                 loading="lazy" />
            <div class="post-author-meta">
              <div class="post-author-name-row">
                <span class="post-author-name">${author.name}</span>
                <span class="post-author-username">@${author.username}</span>
                <span class="post-dot">•</span>
                <span class="post-time">${this.formatTime(post.createdAt)}</span>
              </div>
              ${post.location ? `
                <div class="post-location">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                  <span>${post.location}</span>
                </div>
              ` : ''}
            </div>
          </div>

          ${isOwner ? `
            <button class="post-options-btn" title="Delete post" onclick="Feed.handleDeletePost('${post.id}')">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
            </button>
          ` : ''}
        </header>

        <!-- Post Photo with Double-Tap to Like -->
        <div class="post-media-container" ondblclick="Feed.handleDoubleTapLike('${post.id}')">
          <img src="${post.photoUrl}" alt="${post.caption || 'Photo'}" class="post-image" loading="lazy" />
          <div class="floating-heart" id="floating-heart-${post.id}">
            <svg width="80" height="80" viewBox="0 0 24 24" fill="#f43f5e" stroke="#f43f5e" stroke-width="1.5"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
          </div>
        </div>

        <!-- Post Actions -->
        <div class="post-actions">
          <div class="action-group">
            <button class="btn-action ${isLiked ? 'liked' : ''}" 
                    id="like-btn-${post.id}" 
                    onclick="Feed.handleToggleLike('${post.id}')"
                    title="${isLiked ? 'Unlike' : 'Like'}">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="${isLiked ? '#f43f5e' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
            </button>

            <button class="btn-action" 
                    onclick="Feed.focusCommentInput('${post.id}')"
                    title="Comment">
              <svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
            </button>

            <button class="btn-action" onclick="Feed.handleSharePost('${post.id}')" title="Share post">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
            </button>
          </div>

          <button class="btn-action" onclick="App.showToast('Post bookmarked!', 'info')" title="Bookmark">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>
          </button>
        </div>

        <!-- Post Likes & Caption -->
        <div class="post-details">
          <div class="post-likes-count" id="likes-count-${post.id}">
            ${post.likesCount || 0} ${(post.likesCount === 1) ? 'like' : 'likes'}
          </div>

          ${post.caption ? `
            <div class="post-caption">
              <span class="post-caption-author" onclick="App.viewProfile('${author.username}')">@${author.username}</span>
              <span>${this.formatCaption(post.caption)}</span>
            </div>
          ` : ''}
        </div>

        <!-- Comments Section -->
        <div class="post-comments-container">
          ${post.commentsCount > 0 ? `
            <button class="btn-view-all-comments" onclick="Feed.toggleCommentsThread('${post.id}')" id="view-comments-btn-${post.id}">
              ${isExpanded ? 'Hide comments' : `View all ${post.commentsCount} comments`}
            </button>
          ` : ''}

          <div class="comments-list" id="comments-list-${post.id}" style="${isExpanded ? 'display: flex;' : 'display: none;'}">
            <!-- Dynamically populated or rendered -->
          </div>
        </div>

        <!-- Add Comment Input -->
        <form class="add-comment-form" onsubmit="Feed.handleSubmitComment(event, '${post.id}')">
          <img src="${currentUser ? currentUser.avatar : 'https://api.dicebear.com/7.x/avataaars/svg?seed=guest'}" 
               alt="You" 
               class="user-comment-avatar current-user-avatar" />
          <div class="comment-input-wrap">
            <input type="text" 
                   id="comment-input-${post.id}" 
                   class="comment-input" 
                   placeholder="${currentUser ? 'Add a comment...' : 'Log in to join the conversation...'}" 
                   autocomplete="off"
                   oninput="Feed.handleCommentTyping('${post.id}')" />
            <div class="quick-emojis">
              <button type="button" class="emoji-btn" onclick="Feed.insertEmoji('${post.id}', '❤️')">❤️</button>
              <button type="button" class="emoji-btn" onclick="Feed.insertEmoji('${post.id}', '🔥')">🔥</button>
              <button type="button" class="emoji-btn" onclick="Feed.insertEmoji('${post.id}', '😍')">😍</button>
              <button type="button" class="emoji-btn" onclick="Feed.insertEmoji('${post.id}', '👏')">👏</button>
            </div>
          </div>
          <button type="submit" 
                  class="btn-submit-comment" 
                  id="submit-comment-${post.id}" 
                  disabled>
            Post
          </button>
        </form>
      </article>
    `;
  },

  handleCommentTyping(postId) {
    const input = document.getElementById(`comment-input-${postId}`);
    const submitBtn = document.getElementById(`submit-comment-${postId}`);
    if (input && submitBtn) {
      submitBtn.disabled = !input.value.trim();
    }
  },

  insertEmoji(postId, emoji) {
    const input = document.getElementById(`comment-input-${postId}`);
    if (input) {
      input.value += emoji;
      input.focus();
      this.handleCommentTyping(postId);
    }
  },

  focusCommentInput(postId) {
    const input = document.getElementById(`comment-input-${postId}`);
    if (input) {
      input.focus();
      input.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  },

  async handleToggleLike(postId) {
    if (!Auth.currentUser) {
      Auth.showAuthModal('login');
      App.showToast('Please log in to like posts', 'info');
      return;
    }

    const likeBtn = document.getElementById(`like-btn-${postId}`);
    const countEl = document.getElementById(`likes-count-${postId}`);

    try {
      likeBtn.classList.add('heart-bounce');
      setTimeout(() => likeBtn.classList.remove('heart-bounce'), 400);

      const res = await API.toggleLike(postId);

      // Update UI
      if (res.isLiked) {
        likeBtn.classList.add('liked');
        likeBtn.querySelector('svg').setAttribute('fill', '#f43f5e');
      } else {
        likeBtn.classList.remove('liked');
        likeBtn.querySelector('svg').setAttribute('fill', 'none');
      }

      countEl.textContent = `${res.likesCount} ${res.likesCount === 1 ? 'like' : 'likes'}`;

      // Update in memory cache
      const post = this.posts.find(p => p.id === postId);
      if (post) {
        post.isLikedByMe = res.isLiked;
        post.likesCount = res.likesCount;
      }
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleDoubleTapLike(postId) {
    const heart = document.getElementById(`floating-heart-${postId}`);
    if (heart) {
      heart.classList.add('animate');
      setTimeout(() => heart.classList.remove('animate'), 700);
    }

    const post = this.posts.find(p => p.id === postId);
    if (!post || !post.isLikedByMe) {
      await this.handleToggleLike(postId);
    }
  },

  async toggleCommentsThread(postId) {
    const listEl = document.getElementById(`comments-list-${postId}`);
    const btnEl = document.getElementById(`view-comments-btn-${postId}`);
    if (!listEl) return;

    if (this.expandedComments.has(postId)) {
      this.expandedComments.delete(postId);
      listEl.style.display = 'none';
      if (btnEl) {
        const post = this.posts.find(p => p.id === postId);
        const count = post ? post.commentsCount : '';
        btnEl.textContent = `View all ${count} comments`;
      }
    } else {
      this.expandedComments.add(postId);
      listEl.style.display = 'flex';
      if (btnEl) btnEl.textContent = 'Hide comments';

      // Load comments from API
      listEl.innerHTML = `<div style="font-size: 12px; color: var(--text-muted); padding: 4px 0;">Loading comments...</div>`;
      try {
        const res = await API.getComments(postId);
        this.renderCommentsList(postId, res.comments || []);
      } catch (err) {
        listEl.innerHTML = `<div style="font-size: 12px; color: #f43f5e;">Failed to load comments</div>`;
      }
    }
  },

  renderCommentsList(postId, comments) {
    const listEl = document.getElementById(`comments-list-${postId}`);
    if (!listEl) return;

    if (comments.length === 0) {
      listEl.innerHTML = `<div style="font-size: 12px; color: var(--text-muted); padding: 4px 0;">No comments yet. Say something friendly!</div>`;
      return;
    }

    listEl.innerHTML = comments.map(c => this.renderCommentItem(postId, c)).join('');
  },

  renderCommentItem(postId, comment) {
    const user = comment.user || {};
    const canDelete = comment.canDelete || (Auth.currentUser && comment.userId === Auth.currentUser.id);

    return `
      <div class="comment-item" id="comment-${comment.id}">
        <div class="comment-main">
          <img src="${user.avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=' + user.username}" 
               alt="${user.username}" 
               class="comment-avatar" />
          <div class="comment-content">
            <span class="comment-username" onclick="App.viewProfile('${user.username}')">@${user.username}</span>
            <span class="comment-text">${this.formatCaption(comment.text)}</span>
            <div class="comment-time">${this.formatTime(comment.createdAt)}</div>
          </div>
        </div>

        ${canDelete ? `
          <button class="btn-delete-comment" title="Delete comment" onclick="Feed.handleDeleteComment('${postId}', '${comment.id}')">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          </button>
        ` : ''}
      </div>
    `;
  },

  async handleSubmitComment(e, postId) {
    e.preventDefault();
    if (!Auth.currentUser) {
      Auth.showAuthModal('login');
      App.showToast('Please log in to leave a comment', 'info');
      return;
    }

    const input = document.getElementById(`comment-input-${postId}`);
    const text = input ? input.value.trim() : '';
    if (!text) return;

    const submitBtn = document.getElementById(`submit-comment-${postId}`);
    if (submitBtn) submitBtn.disabled = true;

    try {
      // Optimistic update
      const res = await API.addComment(postId, text);

      // Ensure thread is expanded
      this.expandedComments.add(postId);
      const listEl = document.getElementById(`comments-list-${postId}`);
      if (listEl) {
        listEl.style.display = 'flex';
        // Append new comment
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = this.renderCommentItem(postId, res.comment);
        listEl.appendChild(tempDiv.firstElementChild);
      }

      // Update comment count
      const post = this.posts.find(p => p.id === postId);
      if (post) {
        post.commentsCount = res.commentsCount;
      }
      const btnEl = document.getElementById(`view-comments-btn-${postId}`);
      if (btnEl) btnEl.textContent = 'Hide comments';

      input.value = '';
      App.showToast('Comment posted! 💬', 'success');
    } catch (err) {
      App.showToast(err.message, 'error');
    } finally {
      if (submitBtn) submitBtn.disabled = false;
    }
  },

  async handleDeleteComment(postId, commentId) {
    if (!confirm('Are you sure you want to delete this comment?')) return;

    try {
      const res = await API.deleteComment(postId, commentId);
      const commentEl = document.getElementById(`comment-${commentId}`);
      if (commentEl) {
        commentEl.remove();
      }

      // Update post comment count
      const post = this.posts.find(p => p.id === postId);
      if (post) {
        post.commentsCount = res.commentsCount;
      }

      const btnEl = document.getElementById(`view-comments-btn-${postId}`);
      if (btnEl) {
        if (res.commentsCount === 0) {
          btnEl.style.display = 'none';
        } else {
          btnEl.textContent = this.expandedComments.has(postId) ? 'Hide comments' : `View all ${res.commentsCount} comments`;
        }
      }

      App.showToast('Comment deleted', 'info');
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleDeletePost(postId) {
    if (!confirm('Delete this photo post? This cannot be undone.')) return;

    try {
      await API.deletePost(postId);
      const card = document.getElementById(`post-${postId}`);
      if (card) {
        card.style.opacity = '0';
        card.style.transform = 'scale(0.95)';
        card.style.transition = 'all 0.3s ease';
        setTimeout(() => card.remove(), 300);
      }
      this.posts = this.posts.filter(p => p.id !== postId);
      App.showToast('Post removed successfully', 'info');
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  handleSharePost(postId) {
    const postUrl = `${window.location.origin}/#post-${postId}`;
    navigator.clipboard.writeText(postUrl).then(() => {
      App.showToast('Link copied to clipboard! 📋', 'success');
    }).catch(() => {
      App.showToast('Share URL: ' + postUrl, 'info');
    });
  }
};

window.Feed = Feed;
