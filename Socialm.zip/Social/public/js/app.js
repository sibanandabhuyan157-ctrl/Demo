/**
 * Pulse Social - Main Application Orchestrator
 */

const App = {
  activeView: 'feed', // 'feed' or 'profile'

  async init() {
    console.log('Pulse Social initializing...');
    this.setupDialogLightDismiss();
    this.setupSearch();

    await Auth.init();
    Upload.init();
    await this.loadStories();
    await this.loadFeed();
  },

  // Light dismiss fallback for all <dialog> elements per Modern Web Guidance
  setupDialogLightDismiss() {
    const dialogs = document.querySelectorAll('dialog');
    dialogs.forEach(dialog => {
      if (!('closedBy' in HTMLDialogElement.prototype)) {
        dialog.addEventListener('click', (event) => {
          if (event.target !== dialog) return;
          const rect = dialog.getBoundingClientRect();
          const isDialogContent = (
            rect.top <= event.clientY &&
            event.clientY <= rect.top + rect.height &&
            rect.left <= event.clientX &&
            event.clientX <= rect.left + rect.width
          );
          if (!isDialogContent) {
            dialog.close();
          }
        });
      }
    });
  },

  async loadStories() {
    const container = document.getElementById('storiesBar');
    if (!container) return;

    try {
      const { users } = await API.getDemoUsers();
      container.innerHTML = users.map(user => `
        <div class="story-item" onclick="App.viewProfile('${user.username}')">
          <div class="story-avatar-wrap">
            <img src="${user.avatar}" alt="${user.name}" class="story-avatar" />
          </div>
          <span class="story-username">@${user.username}</span>
        </div>
      `).join('');
    } catch (e) {
      console.warn('Stories failed to load', e);
    }
  },

  async loadFeed(params = {}) {
    this.showView('feed');
    await Feed.loadFeed(params);
  },

  refreshFeed() {
    if (this.activeView === 'feed') {
      Feed.loadFeed();
    } else if (this.currentProfileUsername) {
      this.viewProfile(this.currentProfileUsername);
    }
  },

  showView(viewName) {
    this.activeView = viewName;
    const feedView = document.getElementById('feedView');
    const profileView = document.getElementById('profileView');
    const navHome = document.getElementById('navHome');
    const navProfile = document.getElementById('navProfile');

    if (viewName === 'feed') {
      if (feedView) feedView.style.display = 'block';
      if (profileView) profileView.style.display = 'none';
      if (navHome) navHome.classList.add('active');
      if (navProfile) navProfile.classList.remove('active');
    } else if (viewName === 'profile') {
      if (feedView) feedView.style.display = 'none';
      if (profileView) profileView.style.display = 'block';
      if (navHome) navHome.classList.remove('active');
      if (navProfile) navProfile.classList.add('active');
    }
  },

  async viewProfile(username) {
    if (!username) {
      if (Auth.currentUser) {
        username = Auth.currentUser.username;
      } else {
        Auth.showAuthModal('login');
        return;
      }
    }

    this.currentProfileUsername = username;
    this.showView('profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    const profileContainer = document.getElementById('profileView');
    if (!profileContainer) return;

    profileContainer.innerHTML = `
      <div style="text-align: center; padding: 48px;">
        <div style="display: inline-block; width: 32px; height: 32px; border: 3px solid rgba(99,102,241,0.3); border-top-color: #6366f1; border-radius: 50%; animation: spin 0.8s linear infinite;"></div>
        <p style="margin-top: 12px; color: var(--text-muted);">Loading profile...</p>
      </div>
    `;

    try {
      const { user, posts } = await API.getProfile(username);

      profileContainer.innerHTML = `
        <div class="profile-card">
          <div class="profile-top">
            <img src="${user.avatar}" alt="${user.name}" class="profile-avatar-large" />
            <div style="flex: 1;">
              <div class="profile-name">${user.name}</div>
              <div class="profile-handle">@${user.username}</div>
              <div class="profile-stats-row">
                <div class="profile-stat">
                  <span class="profile-stat-number">${user.postsCount || 0}</span>
                  <span class="profile-stat-label">Posts</span>
                </div>
                <div class="profile-stat">
                  <span class="profile-stat-number">${user.followers || 0}</span>
                  <span class="profile-stat-label">Followers</span>
                </div>
                <div class="profile-stat">
                  <span class="profile-stat-number">${user.following || 0}</span>
                  <span class="profile-stat-label">Following</span>
                </div>
              </div>
            </div>
          </div>
          <div class="profile-bio">${user.bio || 'No bio yet.'}</div>
        </div>

        <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 16px; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px;">
          Photos (${posts.length})
        </h3>

        ${posts.length === 0 ? `
          <div style="text-align: center; padding: 48px; background: var(--bg-secondary); border-radius: var(--radius-lg); border: 1px solid var(--border-color);">
            <div style="font-size: 36px; margin-bottom: 8px;">📷</div>
            <p style="color: var(--text-muted);">No photos shared yet</p>
          </div>
        ` : `
          <div class="profile-grid">
            ${posts.map(p => `
              <div class="profile-grid-item" onclick="App.openPostDetail('${p.id}')">
                <img src="${p.photoUrl}" alt="Photo" class="profile-grid-img" loading="lazy" />
              </div>
            `).join('')}
          </div>
        `}
      `;
    } catch (err) {
      profileContainer.innerHTML = `
        <div style="text-align: center; padding: 48px; color: #f43f5e;">
          <p>${err.message || 'Failed to load profile'}</p>
          <button class="btn-primary" style="width: auto; margin: 16px auto; padding: 8px 18px;" onclick="App.showView('feed')">Back to Feed</button>
        </div>
      `;
    }
  },

  openPostDetail(postId) {
    // Switch to feed and scroll to that post
    this.showView('feed');
    setTimeout(() => {
      const el = document.getElementById(`post-${postId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        el.style.boxShadow = '0 0 0 3px rgba(99, 102, 241, 0.6)';
        setTimeout(() => el.style.boxShadow = '', 2000);
      }
    }, 100);
  },

  setupSearch() {
    const searchInput = document.getElementById('feedSearchInput');
    if (!searchInput) return;

    let debounceTimer;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        const query = e.target.value.trim();
        this.loadFeed({ search: query });
      }, 350);
    });
  },

  searchTag(tag) {
    const searchInput = document.getElementById('feedSearchInput');
    if (searchInput) {
      searchInput.value = `#${tag}`;
    }
    this.loadFeed({ search: tag });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <div style="font-size: 16px;">${type === 'success' ? '✓' : type === 'error' ? '⚠️' : 'ℹ️'}</div>
      <div style="flex: 1;">${message}</div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }
};

window.App = App;

// Bootstrap when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
