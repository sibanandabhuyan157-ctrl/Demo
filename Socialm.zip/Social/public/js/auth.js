/**
 * Pulse Social - Authentication & User State Controller
 */

const Auth = {
  currentUser: null,

  async init() {
    this.currentUser = API.getCurrentUser();

    // Verify token with backend
    if (API.getToken()) {
      try {
        const res = await API.getMe();
        this.currentUser = res.user;
        API.setCurrentUser(res.user);
      } catch (err) {
        console.warn('Session expired or invalid, clearing credentials');
        API.clearToken();
        this.currentUser = null;
      }
    }

    this.renderUserUI();
    await this.loadDemoAccounts();
    this.setupListeners();
  },

  renderUserUI() {
    const userContainer = document.getElementById('sidebarUserContainer');
    const authActions = document.getElementById('authActions');
    const mobileUserAvatar = document.getElementById('mobileUserAvatar');

    if (this.currentUser) {
      if (userContainer) {
        userContainer.innerHTML = `
          <div class="sidebar-user-info" onclick="App.viewProfile('${this.currentUser.username}')">
            <img src="${this.currentUser.avatar}" alt="${this.currentUser.name}" class="sidebar-user-avatar" />
            <div class="sidebar-user-details">
              <div class="sidebar-user-name">${this.currentUser.name}</div>
              <div class="sidebar-user-handle">@${this.currentUser.username}</div>
            </div>
          </div>
          <button class="btn-logout" title="Log out" onclick="Auth.handleLogout()">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
          </button>
        `;
        userContainer.style.display = 'flex';
      }

      if (authActions) {
        authActions.style.display = 'none';
      }

      if (mobileUserAvatar) {
        mobileUserAvatar.src = this.currentUser.avatar;
      }
    } else {
      if (userContainer) {
        userContainer.style.display = 'none';
      }
      if (authActions) {
        authActions.style.display = 'flex';
      }
    }

    // Update avatar on comment inputs
    document.querySelectorAll('.current-user-avatar').forEach(img => {
      img.src = this.currentUser
        ? this.currentUser.avatar
        : 'https://api.dicebear.com/7.x/avataaars/svg?seed=guest';
    });
  },

  async loadDemoAccounts() {
    const listEl = document.getElementById('demoUsersList');
    if (!listEl) return;

    try {
      const { users } = await API.getDemoUsers();
      listEl.innerHTML = users.map(user => {
        const isCurrent = this.currentUser && this.currentUser.username === user.username;
        return `
          <div class="demo-user-card">
            <div class="demo-user-meta" onclick="App.viewProfile('${user.username}')" style="cursor: pointer;">
              <img src="${user.avatar}" alt="${user.name}" class="demo-user-avatar" />
              <div>
                <div class="demo-user-name">${user.name}</div>
                <div class="demo-user-role">@${user.username}</div>
              </div>
            </div>
            <button class="btn-switch-user ${isCurrent ? 'current' : ''}" 
                    onclick="Auth.handleDemoSwitch('${user.username}')" 
                    ${isCurrent ? 'disabled' : ''}>
              ${isCurrent ? 'Active' : 'Switch'}
            </button>
          </div>
        `;
      }).join('');
    } catch (err) {
      console.error('Failed to load demo accounts', err);
    }
  },

  async handleDemoSwitch(username) {
    try {
      App.showToast(`Switching to @${username}...`, 'info');
      const res = await API.demoLogin(username);
      this.currentUser = res.user;
      this.renderUserUI();
      await this.loadDemoAccounts();
      App.showToast(`Logged in as ${res.user.name}!`, 'success');
      App.refreshFeed();
    } catch (err) {
      App.showToast(err.message, 'error');
    }
  },

  async handleLogout() {
    await API.logout();
    this.currentUser = null;
    this.renderUserUI();
    await this.loadDemoAccounts();
    App.showToast('You have been logged out.', 'info');
    App.refreshFeed();
  },

  setupListeners() {
    // Login form submission
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const loginId = document.getElementById('loginUsername').value.trim();
        const password = document.getElementById('loginPassword').value;
        const submitBtn = loginForm.querySelector('button[type="submit"]');

        try {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Logging in...';
          const res = await API.login(loginId, password);
          this.currentUser = res.user;
          this.renderUserUI();
          await this.loadDemoAccounts();

          document.getElementById('authModal').close();
          loginForm.reset();
          App.showToast(`Welcome back, ${res.user.name}!`, 'success');
          App.refreshFeed();
        } catch (err) {
          App.showToast(err.message, 'error');
        } finally {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Log In';
        }
      });
    }

    // Register form submission
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
      registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('regName').value.trim();
        const username = document.getElementById('regUsername').value.trim();
        const email = document.getElementById('regEmail').value.trim();
        const password = document.getElementById('regPassword').value;
        const bio = document.getElementById('regBio').value.trim();
        const avatar = document.getElementById('regAvatar').value.trim();
        const submitBtn = registerForm.querySelector('button[type="submit"]');

        try {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Creating account...';
          const res = await API.register({ name, username, email, password, bio, avatar });
          this.currentUser = res.user;
          this.renderUserUI();
          await this.loadDemoAccounts();

          document.getElementById('authModal').close();
          registerForm.reset();
          App.showToast(`Welcome to Pulse, @${res.user.username}! 🎉`, 'success');
          App.refreshFeed();
        } catch (err) {
          App.showToast(err.message, 'error');
        } finally {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Sign Up';
        }
      });
    }
  },

  showAuthModal(tab = 'login') {
    const modal = document.getElementById('authModal');
    if (!modal) return;

    this.switchAuthTab(tab);
    modal.showModal();
  },

  switchAuthTab(tab) {
    const loginSection = document.getElementById('loginSection');
    const registerSection = document.getElementById('registerSection');
    const tabLogin = document.getElementById('tabLogin');
    const tabRegister = document.getElementById('tabRegister');

    if (tab === 'login') {
      loginSection.style.display = 'block';
      registerSection.style.display = 'none';
      tabLogin.classList.add('active');
      tabRegister.classList.remove('active');
    } else {
      loginSection.style.display = 'none';
      registerSection.style.display = 'block';
      tabLogin.classList.remove('active');
      tabRegister.classList.add('active');
    }
  }
};

window.Auth = Auth;
