const express = require('express');
const db = require('../db');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

// GET /api/posts - Get feed of posts
router.get('/', optionalAuth, (req, res) => {
  try {
    const currentUserId = req.user ? req.user.id : null;
    const { userId, search } = req.query;

    let posts = db.getPosts();

    if (userId) {
      posts = posts.filter(p => p.userId === userId);
    }

    if (search) {
      const term = search.toLowerCase();
      posts = posts.filter(p =>
        (p.caption && p.caption.toLowerCase().includes(term)) ||
        (p.author && p.author.username.toLowerCase().includes(term)) ||
        (p.location && p.location.toLowerCase().includes(term))
      );
    }

    const enriched = posts.map(post => ({
      ...post,
      isLikedByMe: currentUserId ? (post.likes || []).includes(currentUserId) : false,
      isAuthor: currentUserId ? post.userId === currentUserId : false
    }));

    res.json({ posts: enriched });
  } catch (err) {
    console.error('Error fetching posts:', err);
    res.status(500).json({ error: 'Failed to retrieve posts feed' });
  }
});

// GET /api/posts/:id - Get single post with all its comments
router.get('/:id', optionalAuth, (req, res) => {
  try {
    const currentUserId = req.user ? req.user.id : null;
    const post = db.getPostById(req.params.id);

    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    res.json({
      post: {
        ...post,
        isLikedByMe: currentUserId ? (post.likes || []).includes(currentUserId) : false,
        isAuthor: currentUserId ? post.userId === currentUserId : false
      }
    });
  } catch (err) {
    console.error('Error fetching post:', err);
    res.status(500).json({ error: 'Failed to load post' });
  }
});

// POST /api/posts - Create a new post with photo
router.post('/', requireAuth, (req, res) => {
  // Use multer error-handling wrapper
  upload.single('photo')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message || 'File upload failed' });
    }

    try {
      const { caption, location, photoUrl: externalPhotoUrl } = req.body;
      let finalPhotoUrl = '';

      if (req.file) {
        finalPhotoUrl = `/uploads/${req.file.filename}`;
      } else if (externalPhotoUrl && externalPhotoUrl.trim().length > 0) {
        finalPhotoUrl = externalPhotoUrl.trim();
      } else {
        return res.status(400).json({ error: 'Please choose a photo to upload or provide an image URL.' });
      }

      const newPost = db.createPost({
        userId: req.user.id,
        photoUrl: finalPhotoUrl,
        caption: caption || '',
        location: location || ''
      });

      res.status(201).json({
        message: 'Photo posted successfully! 📸',
        post: {
          ...newPost,
          isLikedByMe: false,
          isAuthor: true
        }
      });
    } catch (createErr) {
      console.error('Post creation error:', createErr);
      res.status(500).json({ error: 'Failed to create post' });
    }
  });
});

// POST /api/posts/:id/like - Toggle like on post
router.post('/:id/like', requireAuth, (req, res) => {
  try {
    const result = db.toggleLike(req.params.id, req.user.id);
    if (!result) {
      return res.status(404).json({ error: 'Post not found' });
    }

    res.json({
      message: result.isLiked ? 'Post liked' : 'Post unliked',
      isLiked: result.isLiked,
      likesCount: result.likesCount
    });
  } catch (err) {
    console.error('Like toggle error:', err);
    res.status(500).json({ error: 'Failed to update like status' });
  }
});

// DELETE /api/posts/:id - Delete post
router.delete('/:id', requireAuth, (req, res) => {
  try {
    const success = db.deletePost(req.params.id, req.user.id);
    if (!success) {
      return res.status(403).json({ error: 'Unable to delete post. Either post does not exist or you are not authorized.' });
    }

    res.json({ message: 'Post deleted successfully' });
  } catch (err) {
    console.error('Post delete error:', err);
    res.status(500).json({ error: 'Failed to delete post' });
  }
});

module.exports = router;
