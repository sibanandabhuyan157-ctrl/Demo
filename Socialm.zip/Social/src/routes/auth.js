const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { requireAuth, generateToken } = require('../middleware/auth');

const router = express.Router();

// GET /api/auth/demo-users - List demo accounts for rapid testing
router.get('/demo-users', (req, res) => {
  const users = db.getUsers().slice(0, 3);
  res.json({ users });
});

// POST /api/auth/demo-login - Quick login as a sample user
router.post('/demo-login', (req, res) => {
  const { username } = req.body;
  if (!username) {
    return res.status(400).json({ error: 'Username is required' });
  }

  const user = db.getUserByUsername(username);
  if (!user) {
    return res.status(404).json({ error: 'Demo user not found' });
  }

  const { password, ...safeUser } = user;
  const token = generateToken(safeUser);

  res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000 });
  res.json({
    message: `Logged in as @${safeUser.username}`,
    token,
    user: safeUser
  });
});

// POST /api/auth/register - Create a new account
router.post('/register', async (req, res) => {
  try {
    const { username, name, email, password, avatar, bio } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ error: 'Username, email, and password are required' });
    }

    if (username.length < 3) {
      return res.status(400).json({ error: 'Username must be at least 3 characters' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    // Check if username already exists
    if (db.getUserByUsername(username)) {
      return res.status(409).json({ error: 'Username is already taken' });
    }

    // Check if email already exists
    if (db.getUserByEmail(email)) {
      return res.status(409).json({ error: 'Email is already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = db.createUser({
      username,
      name,
      email,
      password: hashedPassword,
      avatar,
      bio
    });

    const token = generateToken(newUser);
    res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000 });

    res.status(201).json({
      message: 'Account created successfully',
      token,
      user: newUser
    });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Failed to register account' });
  }
});

// POST /api/auth/login - Log into existing account
router.post('/login', async (req, res) => {
  try {
    const { loginId, password } = req.body; // loginId can be username or email

    if (!loginId || !password) {
      return res.status(400).json({ error: 'Username/Email and password are required' });
    }

    let user = db.getUserByUsername(loginId);
    if (!user) {
      user = db.getUserByEmail(loginId);
    }

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials. User not found.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid credentials. Incorrect password.' });
    }

    const { password: _, ...safeUser } = user;
    const token = generateToken(safeUser);

    res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 60 * 60 * 1000 });
    res.json({
      message: 'Login successful',
      token,
      user: safeUser
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Failed to process login' });
  }
});

// GET /api/auth/me - Get current user profile
router.get('/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

// POST /api/auth/logout - Logout
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ message: 'Logged out successfully' });
});

module.exports = router;
