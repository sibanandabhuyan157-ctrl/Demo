const express = require('express');
const db = require('../db');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router({ mergeParams: true });

// GET /api/posts/:postId/comments - Get all comments for a post
router.get('/', optionalAuth, (req, res) => {
  try {
    const currentUserId = req.user ? req.user.id : null;
    const { postId } = req.params;

    const post = db.getPostById(postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const comments = db.getCommentsByPostId(postId).map(c => ({
      ...c,
      isMyComment: currentUserId ? c.userId === currentUserId : false,
      canDelete: currentUserId ? (c.userId === currentUserId || post.userId === currentUserId) : false
    }));

    res.json({ comments });
  } catch (err) {
    console.error('Error fetching comments:', err);
    res.status(500).json({ error: 'Failed to retrieve comments' });
  }
});

// POST /api/posts/:postId/comments - Add a new comment to a post
router.post('/', requireAuth, (req, res) => {
  try {
    const { postId } = req.params;
    const { text } = req.body;

    if (!text || text.trim().length === 0) {
      return res.status(400).json({ error: 'Comment text cannot be empty' });
    }

    const post = db.getPostById(postId);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const comment = db.addComment({
      postId,
      userId: req.user.id,
      text: text.trim()
    });

    if (!comment) {
      return res.status(400).json({ error: 'Failed to add comment' });
    }

    const commentsCount = db.getCommentsByPostId(postId).length;

    res.status(201).json({
      message: 'Comment posted',
      comment: {
        ...comment,
        isMyComment: true,
        canDelete: true
      },
      commentsCount
    });
  } catch (err) {
    console.error('Error adding comment:', err);
    res.status(500).json({ error: 'Failed to post comment' });
  }
});

// DELETE /api/posts/:postId/comments/:commentId - Delete comment
router.delete('/:commentId', requireAuth, (req, res) => {
  try {
    const { postId, commentId } = req.params;
    const success = db.deleteComment(commentId, req.user.id);

    if (!success) {
      return res.status(403).json({ error: 'Unable to delete comment. You may not have permission.' });
    }

    const commentsCount = db.getCommentsByPostId(postId).length;

    res.json({
      message: 'Comment deleted',
      commentsCount
    });
  } catch (err) {
    console.error('Error deleting comment:', err);
    res.status(500).json({ error: 'Failed to delete comment' });
  }
});

module.exports = router;
