const express = require('express');
const db = require('../db');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');

const router = express.Router();

// GET /api/users - List users for suggestions / discovery
router.get('/', optionalAuth, (req, res) => {
  try {
    const currentUserId = req.user ? req.user.id : null;
    const users = db.getUsers()
      .filter(u => u.id !== currentUserId)
      .slice(0, 10);

    res.json({ users });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve users' });
  }
});

// GET /api/users/:username - Get user profile and their posts
router.get('/:username', optionalAuth, (req, res) => {
  try {
    const currentUserId = req.user ? req.user.id : null;
    const user = db.getUserByUsername(req.params.username);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const { password, ...safeUser } = user;
    const userPosts = db.getPosts()
      .filter(p => p.userId === safeUser.id)
      .map(p => ({
        ...p,
        isLikedByMe: currentUserId ? (p.likes || []).includes(currentUserId) : false,
        isAuthor: currentUserId ? p.userId === currentUserId : false
      }));

    res.json({
      user: {
        ...safeUser,
        postsCount: userPosts.length,
        isMe: currentUserId === safeUser.id
      },
      posts: userPosts
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve profile' });
  }
});

// PUT /api/users/profile - Update current user profile
router.put('/profile', requireAuth, (req, res) => {
  try {
    const { name, bio, avatar } = req.body;
    const updated = db.updateUser(req.user.id, { name, bio, avatar });

    if (!updated) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      message: 'Profile updated successfully',
      user: updated
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// POST /api/users/avatar - Upload profile avatar image
router.post('/avatar', requireAuth, (req, res) => {
  upload.single('avatar')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message || 'Avatar upload failed' });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'No avatar image uploaded' });
    }

    const avatarUrl = `/uploads/${req.file.filename}`;
    const updated = db.updateUser(req.user.id, { avatar: avatarUrl });

    res.json({
      message: 'Avatar updated successfully',
      avatarUrl,
      user: updated
    });
  });
});

module.exports = router;
