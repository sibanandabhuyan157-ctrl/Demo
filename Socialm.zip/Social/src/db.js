const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_FILE = path.join(__dirname, '..', 'data', 'db.json');

// Mutex queue for atomic writes
let isWriting = false;
let writeQueue = [];

function processQueue() {
  if (isWriting || writeQueue.length === 0) return;
  isWriting = true;
  const nextData = writeQueue.pop(); // take latest
  writeQueue = []; // drop intermediate states since nextData is latest snapshot

  const tempFile = `${DB_FILE}.tmp`;
  fs.writeFile(tempFile, JSON.stringify(nextData, null, 2), 'utf8', (err) => {
    if (err) {
      console.error('Failed to write temp database file:', err);
      isWriting = false;
      return;
    }
    fs.rename(tempFile, DB_FILE, (renameErr) => {
      isWriting = false;
      if (renameErr) {
        console.error('Failed to commit database file:', renameErr);
      }
      if (writeQueue.length > 0) {
        processQueue();
      }
    });
  });
}

function persistDb(data) {
  writeQueue.push(data);
  processQueue();
}

function getInitialData() {
  const defaultPasswordHash = bcrypt.hashSync('password123', 10);

  const users = [
    {
      id: 'u-sophia',
      username: 'sophia_art',
      name: 'Sophia Martinez',
      email: 'sophia@example.com',
      password: defaultPasswordHash,
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80',
      bio: 'Photographer & visual storyteller 🎨 Nature, portraits & golden hours.',
      followers: 1240,
      following: 382,
      createdAt: '2026-09-01T10:00:00.000Z'
    },
    {
      id: 'u-alex',
      username: 'alex_adventures',
      name: 'Alex Chen',
      email: 'alex@example.com',
      password: defaultPasswordHash,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=250&q=80',
      bio: 'Wanderlust explorer 🏔️ Coffee enthusiast ☕ Always chasing horizons.',
      followers: 950,
      following: 410,
      createdAt: '2026-09-02T11:00:00.000Z'
    },
    {
      id: 'u-elena',
      username: 'elena_tech',
      name: 'Elena Rostova',
      email: 'elena@example.com',
      password: defaultPasswordHash,
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=250&q=80',
      bio: 'Frontend engineer & modern UI enthusiast 💻✨ Minimalist architecture lover.',
      followers: 1820,
      following: 520,
      createdAt: '2026-09-03T12:00:00.000Z'
    }
  ];

  const posts = [
    {
      id: 'p-1',
      userId: 'u-sophia',
      photoUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
      caption: 'Quiet reflections at sunrise in Yosemite Valley 🏔️✨ Nature truly speaks when you stop to listen. #landscape #photography #nature',
      location: 'Yosemite National Park, California',
      likes: ['u-alex', 'u-elena'],
      createdAt: new Date(Date.now() - 3600000 * 4).toISOString() // 4 hours ago
    },
    {
      id: 'p-2',
      userId: 'u-alex',
      photoUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
      caption: 'Found this aesthetic little coffee corner downtown! The pour-over here is pure art ☕🥐 #coffeelover #urbanexploring #morningvibes',
      location: 'Roast & Brew Artisan Cafe',
      likes: ['u-sophia'],
      createdAt: new Date(Date.now() - 3600000 * 9).toISOString() // 9 hours ago
    },
    {
      id: 'p-3',
      userId: 'u-elena',
      photoUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80',
      caption: 'Late night desk setup aesthetics ✨ Building future social web interfaces with clean CSS and fast interactions. 🚀 #developer #workspace #setup',
      location: 'Silicon Valley Labs',
      likes: ['u-sophia', 'u-alex'],
      createdAt: new Date(Date.now() - 3600000 * 22).toISOString() // 22 hours ago
    }
  ];

  const comments = [
    {
      id: 'c-1',
      postId: 'p-1',
      userId: 'u-alex',
      text: 'The lighting here is unreal, Sophia! What focal length did you shoot this with?',
      createdAt: new Date(Date.now() - 3600000 * 3).toISOString()
    },
    {
      id: 'c-2',
      postId: 'p-1',
      userId: 'u-elena',
      text: 'Adding this to my bucket list immediately! Incredible composition 😍',
      createdAt: new Date(Date.now() - 3600000 * 2).toISOString()
    },
    {
      id: 'c-3',
      postId: 'p-2',
      userId: 'u-sophia',
      text: 'Love the warm tones in this spot! Let\'s go together next weekend ☕',
      createdAt: new Date(Date.now() - 3600000 * 7).toISOString()
    },
    {
      id: 'c-4',
      postId: 'p-3',
      userId: 'u-alex',
      text: 'That mechanical keyboard looks crisp! Sleek minimal setup 🔥',
      createdAt: new Date(Date.now() - 3600000 * 18).toISOString()
    }
  ];

  return { users, posts, comments };
}

let db = null;

function loadDb() {
  if (db) return db;

  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf8');
      db = JSON.parse(content);
      // Ensure expected collections exist
      if (!Array.isArray(db.users)) db.users = [];
      if (!Array.isArray(db.posts)) db.posts = [];
      if (!Array.isArray(db.comments)) db.comments = [];
      return db;
    } catch (e) {
      console.error('Error reading db.json, re-initializing with seed data', e);
    }
  }

  db = getInitialData();
  persistDb(db);
  return db;
}

// User Helpers
function getUsers() {
  const data = loadDb();
  return data.users.map(({ password, ...safeUser }) => safeUser);
}

function getUserById(id) {
  const data = loadDb();
  return data.users.find(u => u.id === id);
}

function getUserByUsername(username) {
  const data = loadDb();
  return data.users.find(u => u.username.toLowerCase() === username.toLowerCase());
}

function getUserByEmail(email) {
  const data = loadDb();
  return data.users.find(u => u.email.toLowerCase() === email.toLowerCase());
}

function createUser(userData) {
  const data = loadDb();
  const newUser = {
    id: `u-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    username: userData.username.trim(),
    name: userData.name ? userData.name.trim() : userData.username.trim(),
    email: userData.email.trim().toLowerCase(),
    password: userData.password, // already hashed
    avatar: userData.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(userData.username)}`,
    bio: userData.bio || 'Hello, I am new here! 👋',
    followers: 0,
    following: 0,
    createdAt: new Date().toISOString()
  };
  data.users.push(newUser);
  persistDb(data);

  const { password, ...safeUser } = newUser;
  return safeUser;
}

function updateUser(id, updates) {
  const data = loadDb();
  const user = data.users.find(u => u.id === id);
  if (!user) return null;

  if (updates.name !== undefined) user.name = updates.name.trim();
  if (updates.bio !== undefined) user.bio = updates.bio.trim();
  if (updates.avatar !== undefined) user.avatar = updates.avatar.trim();

  persistDb(data);
  const { password, ...safeUser } = user;
  return safeUser;
}

// Post Helpers
function getPosts() {
  const data = loadDb();
  // Return posts sorted by createdAt descending, enriched with author and comment count
  return data.posts
    .slice()
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map(post => {
      const author = data.users.find(u => u.id === post.userId) || {
        id: post.userId,
        username: 'unknown',
        name: 'Anonymous',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=unknown'
      };
      const postComments = data.comments.filter(c => c.postId === post.id);
      return {
        ...post,
        likesCount: (post.likes || []).length,
        commentsCount: postComments.length,
        author: {
          id: author.id,
          username: author.username,
          name: author.name,
          avatar: author.avatar
        }
      };
    });
}

function getPostById(postId) {
  const data = loadDb();
  const post = data.posts.find(p => p.id === postId);
  if (!post) return null;

  const author = data.users.find(u => u.id === post.userId) || {
    id: post.userId,
    username: 'unknown',
    name: 'Anonymous',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=unknown'
  };

  const postComments = getCommentsByPostId(postId);

  return {
    ...post,
    likesCount: (post.likes || []).length,
    commentsCount: postComments.length,
    comments: postComments,
    author: {
      id: author.id,
      username: author.username,
      name: author.name,
      avatar: author.avatar
    }
  };
}

function createPost({ userId, photoUrl, caption, location }) {
  const data = loadDb();
  const newPost = {
    id: `p-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    userId,
    photoUrl,
    caption: caption || '',
    location: location || '',
    likes: [],
    createdAt: new Date().toISOString()
  };

  data.posts.unshift(newPost);
  persistDb(data);

  return getPostById(newPost.id);
}

function deletePost(postId, userId) {
  const data = loadDb();
  const postIndex = data.posts.findIndex(p => p.id === postId);
  if (postIndex === -1) return false;

  const post = data.posts[postIndex];
  if (post.userId !== userId) return false; // unauthorized

  data.posts.splice(postIndex, 1);
  // remove associated comments
  data.comments = data.comments.filter(c => c.postId !== postId);
  persistDb(data);
  return true;
}

function toggleLike(postId, userId) {
  const data = loadDb();
  const post = data.posts.find(p => p.id === postId);
  if (!post) return null;

  if (!Array.isArray(post.likes)) post.likes = [];

  const index = post.likes.indexOf(userId);
  let isLiked = false;
  if (index === -1) {
    post.likes.push(userId);
    isLiked = true;
  } else {
    post.likes.splice(index, 1);
    isLiked = false;
  }

  persistDb(data);
  return {
    isLiked,
    likesCount: post.likes.length,
    likes: post.likes
  };
}

// Comment Helpers
function getCommentsByPostId(postId) {
  const data = loadDb();
  return data.comments
    .filter(c => c.postId === postId)
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
    .map(c => {
      const user = data.users.find(u => u.id === c.userId) || {
        id: c.userId,
        username: 'unknown',
        name: 'Anonymous',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=unknown'
      };
      return {
        id: c.id,
        postId: c.postId,
        userId: c.userId,
        text: c.text,
        createdAt: c.createdAt,
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          avatar: user.avatar
        }
      };
    });
}

function addComment({ postId, userId, text }) {
  const data = loadDb();
  const post = data.posts.find(p => p.id === postId);
  if (!post) return null;

  const user = data.users.find(u => u.id === userId);
  if (!user) return null;

  const newComment = {
    id: `c-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    postId,
    userId,
    text: text.trim(),
    createdAt: new Date().toISOString()
  };

  data.comments.push(newComment);
  persistDb(data);

  return {
    id: newComment.id,
    postId: newComment.postId,
    userId: newComment.userId,
    text: newComment.text,
    createdAt: newComment.createdAt,
    user: {
      id: user.id,
      username: user.username,
      name: user.name,
      avatar: user.avatar
    }
  };
}

function deleteComment(commentId, userId) {
  const data = loadDb();
  const commentIndex = data.comments.findIndex(c => c.id === commentId);
  if (commentIndex === -1) return false;

  const comment = data.comments[commentIndex];
  const post = data.posts.find(p => p.id === comment.postId);

  // Author of comment or author of post can delete
  if (comment.userId !== userId && (!post || post.userId !== userId)) {
    return false;
  }

  data.comments.splice(commentIndex, 1);
  persistDb(data);
  return true;
}

module.exports = {
  loadDb,
  getUsers,
  getUserById,
  getUserByUsername,
  getUserByEmail,
  createUser,
  updateUser,
  getPosts,
  getPostById,
  createPost,
  deletePost,
  toggleLike,
  getCommentsByPostId,
  addComment,
  deleteComment
};
