# ⚡ Pulse Social - Photo Sharing & Community Platform

A modern, fast, and feature-rich social media website where users can **sign up, log in, post photos, explore feeds, and comment on each other's posts in real time**.

---

## ✨ Features Included

### 1. 🔐 User Authentication & Profiles
- **Sign Up**: Create an account with name, username, email, password, bio, and custom avatar.
- **Log In**: Secure authentication powered by `bcryptjs` password hashing and JWT sessions.
- **1-Click Test Accounts**: Switch instantly between pre-configured users (`@sophia_art`, `@alex_adventures`, `@elena_tech`) directly from the right sidebar widget to test commenting and liking between different users without logging in and out manually!
- **User Profiles**: View any user's profile card with their bio, follower/following count, total posts, and photo grid.

### 2. 📸 Photo Posting
- **Drag-and-Drop File Upload**: Upload local photos (.png, .jpg, .webp, .gif) with instant live preview.
- **Image URL Support**: Alternatively, paste direct image web links.
- **Captions & Hashtags**: Add rich captions with clickable hashtags (e.g. `#nature`, `#photography`).
- **Location Tagging**: Add photo locations (e.g. "Yosemite National Park").

### 3. 💬 Interactive Commenting System
- **Real-Time Commenting**: Add comments instantly on any post.
- **User Identity**: Comments clearly show commenter's avatar, handle, relative timestamp (*e.g., "5m ago", "Just now"*), and formatted text.
- **Quick Emojis**: 1-click emoji buttons (❤️, 🔥, 😍, 👏) for fast commenting.
- **Comment Moderation**: Comment authors and post owners can delete comments.
- **Expandable Threads**: "View all X comments" toggle to view or collapse discussions.

### 4. ❤️ Social Engagement & Likes
- **Double-Tap to Like**: Double-click or double-tap any photo for an animated floating heart burst!
- **Live Like Count**: Heart button with bounce animation and instant like/unlike toggling.
- **Post Sharing**: 1-click link copying to clipboard with toast notifications.

### 5. 🎨 Modern UI & Experience
- **Responsive Layout**: Designed for both desktop (left sidebar + main feed + right widgets) and mobile (bottom navigation bar).
- **Dark Theme Aesthetics**: Sleek slate aesthetic, glassmorphism, and smooth CSS transitions.
- **Accessible Modals**: Built using modern `<dialog>` specifications with light-dismiss backdrop click support and keyboard navigation.

---

## 🚀 How to Run the Website

### Prerequisites
- Node.js (v18+)

### 1. Start the Server
Open a terminal in `C:\Social` and run:

```bash
npm start
```

### 2. Open in Your Browser
Navigate to:
```
http://localhost:3000
```

---

## 📁 Project Structure

```
C:\Social/
├── data/
│   └── db.json               # Persistent JSON database (Users, Posts, Comments, Likes)
├── uploads/                  # Uploaded photo files
├── src/
│   ├── db.js                 # Data persistence layer & helper queries
│   ├── server.js             # Express application & SPA routing
│   ├── middleware/
│   │   ├── auth.js           # JWT authentication middleware
│   │   └── upload.js         # Multer photo upload config
│   └── routes/
│       ├── auth.js           # /api/auth (register, login, me, demo-login)
│       ├── posts.js          # /api/posts (feed, upload photo, like, delete)
│       ├── comments.js       # /api/posts/:id/comments (list, post, delete)
│       └── users.js          # /api/users (profile, user posts)
├── public/
│   ├── index.html            # Main SPA HTML structure
│   ├── css/
│   │   └── style.css         # Modern styling & responsive design
│   └── js/
│       ├── api.js            # API fetch client
│       ├── auth.js           # Authentication & demo account switcher
│       ├── feed.js           # Feed rendering, likes, comments
│       ├── upload.js         # Photo upload modal & preview
│       └── app.js            # App orchestrator & toasts
├── .env                      # Configuration (PORT=3000, JWT_SECRET)
└── package.json              # Project scripts and dependencies
```

---

## 🧪 Testing the Website

1. Open `http://localhost:3000` in your web browser.
2. In the right sidebar under **"Test Accounts"**, click **Switch** on `@alex_adventures`.
3. Scroll to any post (e.g. Sophia's photo) and type a comment into the comment box, or double-tap the photo to like it!
4. Click **Switch** on `@sophia_art` to see the notification and reply back as Sophia.
5. Click **"Create Post"** to upload your own photo with a caption and location!
